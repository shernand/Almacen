EEEPROM
=======

An Arduino library for the 24C256 EEPROM

The implementation is from http://playground.arduino.cc/Code/I2CEEPROM, I just packaged it into a library.
