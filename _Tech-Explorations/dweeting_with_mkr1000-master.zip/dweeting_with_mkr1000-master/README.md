# dweeting_with_mkr1000
Demo code from the workshop at Mini Maker Fair Athens 2016
