package cc.blynk.server.push.response.enums;

/**
 * The Blynk Project.
 * Created by Dmitriy Dumanskiy.
 * Created on 2/8/2015.
 */
public enum ControlType {

    CONNECTION_DRAINING

}
