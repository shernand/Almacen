package cc.blynk.server.push.response;

/**
 * The Blynk Project.
 * Created by Dmitriy Dumanskiy.
 * Created on 2/8/2015.
 */
public class ACKMessage extends ResponseMessageBase {

    @Override
    public String toString() {
        return "ACKMessage{" + super.toString() + "}";
    }
}
