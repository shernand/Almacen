package cc.blynk.server.model.enums;

/**
 * User: ddumanskiy
 * Date: 21.11.13
 * Time: 13:44
 */
public enum State {

    ON, OFF
}
