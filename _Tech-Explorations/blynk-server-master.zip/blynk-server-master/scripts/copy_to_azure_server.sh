#!/bin/sh
scp ../build/server-0.1.jar azureuser@blynk-test-east.cloudapp.net:/home/azureuser