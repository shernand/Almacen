#!/bin/sh
scp ../build/server-0.1.jar pupkin@192.168.0.64:/home/pupkin/Dropbox/blynk_new