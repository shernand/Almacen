# Arduino Light Seeking and Obstacle Avoiding Robot

This is the code for my arduino robot.
Each file contains code for each component so that you can understand how it works.
Simply download or paste it in the Arduino IDE and have fun!

The link to my instructables page for this project
http://www.instructables.com/id/Light-Seeking-and-Obstacle-Avoiding-Robot/
