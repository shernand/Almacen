# KicadLikeAPro-Project-3-BACEE

This is one of the PCB projects from the [Kicad Like a Pro](https://techexplorations.com/so/kicada/) book and video course. It contains a two and four layer board that implements an Arduino clone with external EEPROM and a clock.

