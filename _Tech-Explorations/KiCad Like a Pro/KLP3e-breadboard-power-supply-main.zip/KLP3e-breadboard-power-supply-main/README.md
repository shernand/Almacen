# Breadboard power supply, a Kicad project

This is the repository for the "Breadboard power supply" project.

This is one of the projects from the course [KiCad Like a Pro, 3rd edition](https://techexplorations.com/so/kicad-like-a-pro-3rd-edition/).
