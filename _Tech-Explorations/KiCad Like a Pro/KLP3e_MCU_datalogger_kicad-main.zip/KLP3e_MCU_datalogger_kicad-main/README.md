View this project on [CADLAB.io](https://cadlab.io/project/24569). 

# MCU datalogger, a Kicad project

This is the repository for the "MCU datalogger" project.

This is one of the projects from the course [KiCad Like a Pro, 3rd edition](https://techexplorations.com/so/kicad-like-a-pro-3rd-edition/).
