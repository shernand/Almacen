# KiCad Like a Pro 3e resources

This page contains resources from the eBook and video course

This is one of the projects from the course [KiCad Like a Pro, 3rd edition](https://techexplorations.com/so/kicad-like-a-pro-3rd-edition/).
