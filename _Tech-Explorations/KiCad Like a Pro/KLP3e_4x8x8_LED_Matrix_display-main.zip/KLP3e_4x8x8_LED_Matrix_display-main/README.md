# KLP3e 4x8x8 LED Matrix, a Kicad project

This is the repository for the "4x8x8 LED Matrix display" project.

This is one of the projects from the course [KiCad Like a Pro, 3rd edition](https://techexplorations.com/so/kicad-like-a-pro-3rd-edition/).
