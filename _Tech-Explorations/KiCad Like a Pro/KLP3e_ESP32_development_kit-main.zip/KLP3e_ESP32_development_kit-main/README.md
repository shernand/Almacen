# KLP3e ESP32 development kit, a Kicad project

This is the repository for the "ESP32 Devkit clone" project.

This is one of the projects from the course [KiCad Like a Pro, 3rd edition](https://techexplorations.com/so/kicad-like-a-pro-3rd-edition/).
