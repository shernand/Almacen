# Raspberry Pi Full Stack Upgrade Project

This is the repository for Raspberry Pi Full Stack Upgrade Project, a course from [Tech Explorations](https://techexplorations.com).

[Learn more about this course](https://techexplorations.com/so/rpifs_up).
