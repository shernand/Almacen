# arduino_iot_cloud
Scripts, sketches, and schematics from the course
