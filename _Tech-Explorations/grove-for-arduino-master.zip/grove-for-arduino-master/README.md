# grove-for-arduino
This repository contains code used in the course from Tech Explorations. 

For information about this course, please see

https://techexplorations.com/so/grove/

For information on hardware components and the wiring needed to 
run the sketches in this repository, please see the relevant lecture in the course.

Created by Peter Dalmaris.
