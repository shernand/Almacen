## 3DR EAI

Based on: KAP UAV Exposure Control Script v3.1
  -- Released under GPL by waterwingz and wayback/peabody
  http://chdk.wikia.com/wiki/KAP_%26_UAV_Exposure_Control_Script