# KiCon Raffle sketch
I used this sketch, running on an ESP32 with a 2.8" TFT screen, to draw a lucky number for the ticket raffle.
