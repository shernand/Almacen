### Please go to the course home page to learn more about this course.

https://app.techexplorations.com/courses/node-red-esp32-make-a-terrarium-controller/

This repository contains ESP32 sketches and Node-RED flows from the course "NodeRed ESP32 Make a Terrarium Controller".

