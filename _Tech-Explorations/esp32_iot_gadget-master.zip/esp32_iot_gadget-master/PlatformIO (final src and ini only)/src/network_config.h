#include <Arduino.h>

#define IO_USERNAME    "futureshocked"
#define IO_KEY         "c10ce8eff2ad45c499dd864629ae40e2"

#define WIFI_SSID       "ardwifi"
#define WIFI_PASS       "ardwifi987"

#include "AdafruitIO_WiFi.h"

