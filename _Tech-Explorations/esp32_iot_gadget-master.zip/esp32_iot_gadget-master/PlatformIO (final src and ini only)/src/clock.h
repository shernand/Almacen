#include <Arduino.h>
#include "settings.h"

void refresh_clock(TFT_eSPI* tft, Timezone* timezone);