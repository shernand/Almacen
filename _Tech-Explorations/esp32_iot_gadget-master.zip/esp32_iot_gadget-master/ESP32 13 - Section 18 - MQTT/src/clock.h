#include <Arduino.h>
#include "settings.h"

void printLocalTime();
void refresh_clock(TFT_eSPI* tft);