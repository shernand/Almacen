#include <Arduino.h>
#include "settings.h"

void indicators();
// void wifiStatus();