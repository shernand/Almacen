#include <Arduino.h>

/************************ Adafruit IO Config *******************************/

// visit io.adafruit.com if you need to create an account,
// or if you need your Adafruit IO key.
#define IO_USERNAME    "<<--your adarfuit IO username-->>"
#define IO_KEY         "<<--your adarfuit IO IO key-->>"

/******************************* WIFI **************************************/
#define WIFI_SSID       "<<--your wifi ssid-->>"
#define WIFI_PASS       "<<--your wifi password-->>"

#include "AdafruitIO_WiFi.h"   
AdafruitIO_WiFi io(IO_USERNAME, IO_KEY, WIFI_SSID, WIFI_PASS);
