#include <Arduino.h>

void indicators();
// void wifiStatus();